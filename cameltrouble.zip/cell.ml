type t = {x: int; y: int}

let make_cell x y = {x; y}