(* Hours worked per developer for CamelTrouble *)
let hours_worked = [20; 20; 20]
