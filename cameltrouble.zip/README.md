# CamelTrouble
TankTrouble, but make it OCaml
